﻿param(
  [Parameter(Mandatory=$true)][string]$ZipPath,
  [Parameter(Mandatory=$true)][string]$InstallDir,
  [Parameter(Mandatory=$true)][string]$ExePath,
  [Parameter(Mandatory=$true)][int]$ProcessId
)
$ErrorActionPreference='Stop'
$log=Join-Path $env:TEMP 'INITIALTEC_ERP_Update.log'
$extract=Join-Path $env:TEMP ("INITIALTEC_ERP_Update_"+[Guid]::NewGuid().ToString('N'))
try {
  "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] update start" | Set-Content -Path $log -Encoding UTF8
  for($i=0;$i -lt 180;$i++) {
    if(-not (Get-Process -Id $ProcessId -ErrorAction SilentlyContinue)){ break }
    Start-Sleep -Milliseconds 500
  }
  if(Get-Process -Id $ProcessId -ErrorAction SilentlyContinue){ throw 'ERP 프로그램이 90초 안에 종료되지 않았습니다.' }
  Start-Sleep -Milliseconds 800
  New-Item -ItemType Directory -Force -Path $extract | Out-Null
  Expand-Archive -LiteralPath $ZipPath -DestinationPath $extract -Force
  if(-not (Test-Path -LiteralPath (Join-Path $extract 'INITIALTEC_ERP.exe'))){ throw '압축 안에 INITIALTEC_ERP.exe가 없습니다.' }
  New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null

  # 서버 주소는 PC마다 다른 사용자 설정값입니다. 업데이트 패치가 절대 덮어쓰지 않습니다.
  $serverUrlPath=Join-Path $InstallDir 'ERP_SERVER_URL.txt'
  $savedServerUrl=$null
  if(Test-Path -LiteralPath $serverUrlPath){$savedServerUrl=(Get-Content -LiteralPath $serverUrlPath -Raw -ErrorAction SilentlyContinue)}

  Get-ChildItem -LiteralPath $extract -Force | ForEach-Object {
    if($_.Name -ine 'ERP_SERVER_URL.txt'){Copy-Item -LiteralPath $_.FullName -Destination $InstallDir -Recurse -Force}
  }
  if($null -ne $savedServerUrl){Set-Content -LiteralPath $serverUrlPath -Value $savedServerUrl.Trim() -Encoding ascii}
  "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] files copied" | Add-Content -Path $log -Encoding UTF8
  Start-Process -FilePath $ExePath -WorkingDirectory $InstallDir
  "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] restart requested" | Add-Content -Path $log -Encoding UTF8
}
catch {
  "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] ERROR: $($_.Exception.Message)" | Add-Content -Path $log -Encoding UTF8
  try {
    Add-Type -AssemblyName PresentationFramework
    [System.Windows.MessageBox]::Show("ERP 업데이트 적용에 실패했습니다.`n`n$($_.Exception.Message)`n`n로그: $log",'INITIALTEC ERP 업데이트 오류') | Out-Null
  } catch {}
}
finally {
  try { if(Test-Path -LiteralPath $extract){Remove-Item -LiteralPath $extract -Recurse -Force} } catch {}
  try { if(Test-Path -LiteralPath $ZipPath){Remove-Item -LiteralPath $ZipPath -Force} } catch {}
  try { Remove-Item -LiteralPath $PSCommandPath -Force } catch {}
}
